from pymongo import MongoClient


class AnimalShelter(object):

    def __init__(self, username, password):
        USER = username
        PASS = password
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        self.client = MongoClient(
            'mongodb://%s:%s@%s:%d/?authSource=admin' %
            (USER, PASS, HOST, PORT)
        )

        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print("Create Error:", e)
                return False
        else:
            raise Exception("Nothing to save, data parameter is empty")

    def read(self, query):
        try:
            data = self.collection.find(query, {"_id": False})
            return list(data)
        except Exception as e:
            print("Read Error:", e)
            return []

    def update(self, query, new_values):
        try:
            result = self.collection.update_many(
                query,
                {"$set": new_values}
            )
            return result.modified_count
        except Exception as e:
            print("Update Error:", e)
            return 0

    def delete(self, query):
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print("Delete Error:", e)
            return 0